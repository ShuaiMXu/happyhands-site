'use client';

import {cva, type VariantProps} from 'class-variance-authority';
import {Fragment, memo, useEffect, useMemo, useRef, useState} from 'react';
import {cn} from '@/lib/glaze/utils';
import {CodeBlock, type Language} from '@/components/glaze/ui/code-block';
import {Status} from '@/components/glaze/ui/status';

// Markdown that renders as it streams, in Glaze's type: body text at 14/1.5 (13 at size sm), headings in the label
// roles, and every bit of code in mono at 0.8 of the text around it, so it never looks a size bigger. Inline code is a
// run of mono on the grey field with no padding above or below, so the line never grows; a fenced block is Glaze's
// CodeBlock, on its code surface, with its language and copy in the header.
//
// Paced reveal. A delta of 512 characters or fewer renders at once. A bigger
// burst drains every 24ms in slices that grow with the backlog (2, 4, 8, then a quarter of it, at most
// 256), and each slice snaps forward up to 8 characters to the next space or punctuation, so a word is
// never cut in half. Any change that is not an append resyncs at once. Reduced motion, a hidden tab and
// the end of the stream all show the full text immediately.
//
// Block-frozen parsing. The source splits into chunks at blank lines outside fences and tags. Every
// chunk but the last is frozen: memoised on its own text, so it never re-renders while the tail grows.
// Only the live tail re-parses, with dangling syntax closed (a lone ** or `, a half link, a table whose
// separator has not arrived). An open fence renders as an open code block and grows by appending.
// The same parser runs before and after the stream ends, so nothing flashes when it settles.
//
// Structured tags (<refund-card>{json}</refund-card>) have four outcomes:
//   segment  the tag closed (or its JSON value completed) and the body parsed: its renderer draws it
//   discard  the body is broken JSON: nothing shows, never raw JSON
//   literal  a JSON tag whose body is plain prose, or a text tag that never closed: shown as text
//   pending  the body is still a viable JSON prefix: the renderer's placeholder shows
// Only registered tag names open a tag chunk. An unknown tag (<details>, <br>) stays in the markdown
// flow as text, so it can never swallow the lines after it.
// A JSON tag keeps its placeholder while its body is still a viable prefix, even when it stalls, so the
// box never collapses and comes back; prose that follows a broken prefix shows at once, and at the end
// of the stream an unfinished value is discarded. A text tag (json: false) that goes `tagTimeout` ms
// without growing, or is still open when the stream ends, shows its opening line as text and the rest
// of the answer parses as markdown again.
//
// It never writes raw HTML. Links accept http(s), mailto, same-site paths and anchors; anything else
// (javascript:, data:) renders as its label only.

// ---------- Paced reveal ----------

const PACE_MS = 24;
const IMMEDIATE = 512;
const SNAP = /[\s.,!?;:)\]]/;

function paceStep(backlog: number) {
  if (backlog <= 12) return 2;
  if (backlog <= 48) return 4;
  if (backlog <= 96) return 8;
  return Math.min(256, Math.ceil(backlog / 4));
}

/** The end of the next slice from `start`, snapped forward up to 8 characters to a word edge. */
function nextCut(text: string, start: number) {
  const end = Math.min(text.length, start + paceStep(text.length - start));
  const max = Math.min(text.length, end + 8);
  for (let i = end; i < max; i++) if (SNAP.test(text[i] ?? '')) return i + 1;
  return end;
}

const prefersReduced = () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/** The text to show for `text` while `live`, paced as above. Returns the full text when not live. */
function usePacedText(text: string, live: boolean, enabled = true) {
  const [shown, setShown] = useState(text);
  const shownRef = useRef(text);
  const latest = useRef(text);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  latest.current = text;

  useEffect(() => {
    const sync = (value: string) => { shownRef.current = value; setShown(value); };
    const clear = () => { if (timer.current) clearTimeout(timer.current); timer.current = undefined; };
    const instant = !live || !enabled || prefersReduced() || (typeof document !== 'undefined' && document.hidden);
    const run = () => {
      timer.current = undefined;
      const full = latest.current;
      const now = shownRef.current;
      if (!full.startsWith(now) || full.length - now.length <= IMMEDIATE) { sync(full); return; }
      const end = nextCut(full, now.length);
      sync(full.slice(0, end));
      if (end < full.length) timer.current = setTimeout(run, PACE_MS);
    };
    if (instant || !text.startsWith(shownRef.current)) { clear(); sync(text); return; }
    if (text.length - shownRef.current.length <= IMMEDIATE && !timer.current) { sync(text); return; }
    if (!timer.current) run();
  }, [text, live, enabled]);

  // A tab that comes back, or a page restored from the back-forward cache, resyncs instead of replaying.
  useEffect(() => {
    const resync = () => { if (timer.current) clearTimeout(timer.current); timer.current = undefined; shownRef.current = latest.current; setShown(latest.current); };
    const onVisible = () => { if (!document.hidden) resync(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('pageshow', resync);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('pageshow', resync);
      if (timer.current) clearTimeout(timer.current);
    };
  }, []);

  return live && enabled ? shown : text;
}

// ---------- JSON viability ----------

/** Where the first complete top-level object or array ends in `s`, or -1. */
function completeJsonEnd(s: string) {
  let depth = 0, inStr = false, esc = false, started = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') inStr = true;
    else if (ch === '{' || ch === '[') { depth++; started = true; }
    else if (ch === '}' || ch === ']') { depth--; if (started && depth === 0) return i + 1; if (depth < 0) return -1; }
  }
  return -1;
}

/** Closes an unfinished JSON prefix so JSON.parse can judge it: strings, keys, literals, containers. */
function closeJson(prefix: string) {
  const stack: string[] = [];
  let inStr = false, esc = false, strStart = -1;
  for (let i = 0; i < prefix.length; i++) {
    const ch = prefix[i];
    if (inStr) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') inStr = false; continue; }
    if (ch === '"') { inStr = true; strStart = i; }
    else if (ch === '{' || ch === '[') stack.push(ch);
    else if (ch === '}' || ch === ']') stack.pop();
  }
  let out = prefix;
  if (inStr) out = (esc ? out.slice(0, -1) : out) + '"';
  out = out.replace(/\s+$/, '');
  const lastStr = inStr ? strStart : -1;
  if (/[,]$/.test(out)) out = out.slice(0, -1);
  else if (/:$/.test(out)) out += 'null';
  else if (/(?:^|[^\w"])(t|tr|tru)$/.test(out)) out = out.replace(/(t|tr|tru)$/, 'true');
  else if (/(?:^|[^\w"])(f|fa|fal|fals)$/.test(out)) out = out.replace(/(f|fa|fal|fals)$/, 'false');
  else if (/(?:^|[^\w"])(n|nu|nul)$/.test(out)) out = out.replace(/(n|nu|nul)$/, 'null');
  else if (/[-+.eE]$/.test(out)) out += '0';
  // A key string with no colon yet: {"env" or {"a":1,"env"
  if (stack.at(-1) === '{' && out.endsWith('"')) {
    const start = lastStr !== -1 ? lastStr : out.lastIndexOf('"', out.length - 2);
    const before = out.slice(0, start).replace(/\s+$/, '').at(-1);
    if (before === '{' || before === ',') out += ':null';
  }
  for (let i = stack.length - 1; i >= 0; i--) out += stack[i] === '{' ? '}' : ']';
  return out;
}

function viable(prefix: string) {
  if (!prefix.trim()) return true;
  try { JSON.parse(closeJson(prefix)); return true; } catch { return false; }
}

/** The length of the longest prefix of `s` that can still become JSON. 0 when it does not start like JSON. */
function viableLength(s: string) {
  const lead = s.length - s.trimStart().length;
  if (!/^[[{]/.test(s.trimStart())) return s.trim() ? 0 : s.length;
  if (viable(s)) return s.length;
  let lo = lead + 1, hi = s.length;
  while (lo < hi) {
    const mid = Math.ceil((lo + hi) / 2);
    if (viable(s.slice(0, mid))) lo = mid; else hi = mid - 1;
  }
  return lo;
}

// ---------- Tags ----------

type TagRenderer = {
  /** What the placeholder says while the tag is still open: "Preparing refund". */
  pending: string;
  /** Draws the finished tag. `data` is the parsed JSON body, or the raw body when json is false. */
  render: (data: unknown, attrs: Record<string, string>) => React.ReactNode;
  /** The body is JSON. Defaults to true. */
  json?: boolean;
};

type TagOutcome = 'segment' | 'discard' | 'literal' | 'pending';

type InlineTag = {
  /** Matches one token in running text. Flags other than i, u and s are ignored. */
  pattern: RegExp;
  render: (match: RegExpMatchArray, context: {streaming: boolean; key: number}) => React.ReactNode;
  /** A half-typed token at the very end of the stream, held back until it completes: /\[\d*$/. */
  partial?: RegExp;
};

const attrPattern = /([\w-]+)="([^"]*)"/g;
const parseAttrs = (raw: string) => Object.fromEntries([...raw.matchAll(attrPattern)].map(m => [m[1], m[2]]));
const tagOpen = /^<([a-z][\w-]*)((?:\s+[\w-]+="[^"]*")*)\s*>/;

// ---------- Chunks ----------

type Chunk = {text: string; kind: 'md' | 'fence' | 'tag'; start: number};

/** Splits at blank lines, keeping fences and registered tags whole. The last chunk is the live tail. */
function splitChunks(source: string, isTag: (name: string) => boolean = () => true): Chunk[] {
  const lines = source.split('\n');
  const chunks: Chunk[] = [];
  let buf: string[] = [];
  let bufStart = 0;
  let offset = 0;
  const flush = () => { if (buf.length && buf.some(l => l.trim())) chunks.push({text: buf.join('\n'), kind: 'md', start: bufStart}); buf = []; };
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const fence = line.match(/^(\s{0,3})(`{3,}|~{3,})/);
    const opened = line.match(tagOpen);
    const tag = opened && isTag(opened[1]) ? opened : null;
    if (fence || tag) {
      flush();
      const start = offset;
      const body = [line];
      offset += line.length + 1;
      if (fence) {
        const close = new RegExp(`^\\s{0,3}${fence[2][0]}{${fence[2].length},}\\s*$`);
        while (++i < lines.length) { body.push(lines[i]); offset += lines[i].length + 1; if (close.test(lines[i])) break; }
        chunks.push({text: body.join('\n'), kind: 'fence', start});
      } else {
        const close = `</${tag![1]}>`;
        let closed = line.includes(close);
        while (!closed && ++i < lines.length) { body.push(lines[i]); offset += lines[i].length + 1; closed = lines[i].includes(close); }
        chunks.push({text: body.join('\n'), kind: 'tag', start});
      }
      bufStart = offset;
      continue;
    }
    if (!line.trim()) { flush(); offset += line.length + 1; bufStart = offset; continue; }
    if (!buf.length) bufStart = offset;
    buf.push(line);
    offset += line.length + 1;
  }
  flush();
  return chunks;
}

// ---------- Blocks ----------

type Block =
  | {type: 'p' | 'quote'; text: string}
  | {type: 'h'; level: 1 | 2 | 3; text: string}
  | {type: 'ul' | 'ol'; items: string[]}
  | {type: 'hr'}
  | {type: 'table'; head: string[]; rows: string[][]};

const cells = (row: string) => row.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());

function parseMarkdown(source: string, tail: boolean): Block[] {
  const lines = source.split('\n');
  const blocks: Block[] = [];
  let para: string[] = [];
  const flush = () => { if (para.length) blocks.push({type: 'p', text: para.join(' ')}); para = []; };
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) { flush(); continue; }
    if (/^\s*\|/.test(line)) {
      flush();
      const rows: string[] = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) rows.push(lines[i++]);
      i--;
      const sep = rows[1] && /^\s*\|?\s*:?-{2,}/.test(rows[1]);
      // A half table holds back: no separator yet, or a last row still being typed.
      if (!sep) { if (!tail) rows.forEach(r => para.push(r)); continue; }
      const body = rows.slice(2);
      if (tail && body.length && !/\|\s*$/.test(body.at(-1)!)) body.pop();
      blocks.push({type: 'table', head: cells(rows[0]), rows: body.map(cells)});
      continue;
    }
    const heading = line.match(/^(#{1,3})\s+(.*)$/);
    if (heading) { flush(); blocks.push({type: 'h', level: heading[1].length as 1 | 2 | 3, text: heading[2]}); continue; }
    if (/^(-{3,}|\*{3,})\s*$/.test(line)) { flush(); blocks.push({type: 'hr'}); continue; }
    const quote = line.match(/^>\s?(.*)$/);
    if (quote) {
      flush();
      const prev = blocks.at(-1);
      if (prev?.type === 'quote') prev.text += ` ${quote[1]}`; else blocks.push({type: 'quote', text: quote[1]});
      continue;
    }
    const item = line.match(/^\s*(?:([-*+])|(\d+)[.)])\s+(.*)$/);
    if (item) {
      flush();
      const type = item[1] ? 'ul' : 'ol';
      const prev = blocks.at(-1);
      if (prev && prev.type === type) prev.items.push(item[3]); else blocks.push({type, items: [item[3]]});
      continue;
    }
    const prev = blocks.at(-1);
    if (!para.length && prev && (prev.type === 'ul' || prev.type === 'ol') && /^\s+\S/.test(line)) {
      prev.items[prev.items.length - 1] += ` ${line.trim()}`;
      continue;
    }
    para.push(line.trim());
  }
  flush();
  return blocks;
}

/** Closes dangling syntax at the live edge: ** and ` are closed, a half link shows its label. */
function heal(text: string, inlineTags: InlineTag[]) {
  let out = text;
  for (const tag of inlineTags) if (tag.partial) out = out.replace(tag.partial, '');
  out = out.replace(/\[([^\]]*)\]\([^)]*$/, '$1').replace(/\[([^\]]*)$/, '$1');
  if ((out.match(/`/g)?.length ?? 0) % 2) out += '`';
  if ((out.replace(/`[^`]*`/g, '').match(/\*\*/g)?.length ?? 0) % 2) out = /\*\*\s*$/.test(out) ? out.replace(/\*\*\s*$/, '') : out + '**';
  return out.replace(/(^|\s)[*_]$/, '$1');
}

const safeHref = (href: string) => /^(https?:\/\/|mailto:|\/(?!\/)|#)/i.test(href) ? href : undefined;

const builtins = [
  '`[^`]+`',
  '\\*\\*[^*]+\\*\\*',
  '\\*[^*\\s][^*]*\\*|(?<![\\w])_[^_\\s][^_]*_(?![\\w])',
  // A link whose URL may hold one level of balanced parentheses: [x](javascript:alert(1)), /a_(b).
  '\\[[^\\]]+\\]\\((?:[^()\\s]|\\([^()\\s]*\\))+\\)',
];
const tagFlags = (re: RegExp) => re.flags.replace(/[^ius]/g, '');
const noTags: InlineTag[] = [];
const patternCache = new WeakMap<InlineTag[], {all: RegExp; whole: RegExp[]}>();
function inlinePatterns(tags: InlineTag[]) {
  let hit = patternCache.get(tags);
  if (!hit) {
    const flags = [...new Set(tags.flatMap(t => [...tagFlags(t.pattern)]))].join('');
    hit = {
      all: new RegExp([...builtins, ...tags.map(t => t.pattern.source)].map(src => `(${src})`).join('|'), `g${flags}`),
      whole: tags.map(t => new RegExp(`^(?:${t.pattern.source})$`, tagFlags(t.pattern))),
    };
    patternCache.set(tags, hit);
  }
  return hit;
}

function Inline({text, tags = noTags, streaming = false}: {text: string; tags?: InlineTag[]; streaming?: boolean}) {
  const {all, whole} = inlinePatterns(tags);
  const parts: React.ReactNode[] = [];
  let at = 0;
  let key = 0;
  for (const m of text.matchAll(all)) {
    if (m.index > at) parts.push(text.slice(at, m.index));
    const token = m[0];
    if (m[1]) parts.push(<code key={key++} className="rounded-tag well px-1 text-text-1 [overflow-wrap:anywhere]">{token.slice(1, -1)}</code>);
    else if (m[2]) parts.push(<strong key={key++} className="font-semibold text-text-1"><Inline text={token.slice(2, -2)} tags={tags} streaming={streaming}/></strong>);
    else if (m[3]) parts.push(<em key={key++}><Inline text={token.slice(1, -1)} tags={tags} streaming={streaming}/></em>);
    else if (m[4]) {
      const [, label, href] = token.match(/^\[([^\]]+)\]\((.+)\)$/) ?? [];
      const safe = safeHref(href ?? '');
      parts.push(safe
        ? <a key={key++} href={safe} className="text-text-1 underline decoration-1 underline-offset-4 transition-[text-decoration-color,outline-color] duration-(--dur-state) hover:decoration-2 [overflow-wrap:anywhere]" {...(/^https?:/i.test(safe) ? {target: '_blank', rel: 'noreferrer noopener'} : {})}>{label}</a>
        : <Fragment key={key++}>{label}</Fragment>);
    } else {
      const i = whole.findIndex(re => re.test(token));
      const match = i === -1 ? null : token.match(whole[i]);
      parts.push(match ? <Fragment key={key++}>{tags[i].render(match, {streaming, key})}</Fragment> : token);
    }
    at = m.index + token.length;
  }
  if (at < text.length) parts.push(text.slice(at));
  return <>{parts.map((part, i) => <Fragment key={i}>{part}</Fragment>)}</>;
}

function renderBlocks(blocks: Block[], ctx: {tail: boolean; tags: InlineTag[]; streaming: boolean}) {
  const last = ctx.tail ? blocks.findLastIndex(b => b.type !== 'hr' && b.type !== 'table') : -1;
  return blocks.map((block, i) => {
    const live = i === last;
    const text = (value: string, heals = live) => <Inline text={heals ? heal(value, ctx.tags) : value} tags={ctx.tags} streaming={ctx.streaming}/>;
    switch (block.type) {
      case 'p': return <p key={i}>{text(block.text)}</p>;
      case 'quote': return <blockquote key={i} className="ps-3 text-text-2">{text(block.text)}</blockquote>;
      case 'h': {
        const H = (`h${block.level + 2}`) as 'h3' | 'h4' | 'h5';
        return <H key={i} className={cn('pt-1 text-text-1', block.level === 1 ? 'type-heading-sm' : block.level === 2 ? 'type-label-lg' : 'type-label')}>{text(block.text)}</H>;
      }
      case 'ul':
      case 'ol': {
        const List = block.type;
        return <List key={i} className="flex flex-col gap-1">
          {/* A bullet is an 8px hairline dash, never a dot. Marker and number share a 16px cell and one gap, so the text of a bullet list and a numbered one starts on the same column. */}
          {block.items.map((item, j) => <li key={j} className="flex gap-2">
            {block.type === 'ul'
              ? <span aria-hidden className="flex h-lh w-4 shrink-0 items-center"><span className="h-px w-2 bg-text-2 forced-colors:bg-[CanvasText]"/></span>
              : <span aria-hidden className="min-w-4 shrink-0 text-text-2 data">{j + 1}.</span>}
            <span className="min-w-0">{text(item, live && j === block.items.length - 1)}</span>
          </li>)}
        </List>;
      }
      case 'hr': return <hr key={i} className="h-px border-0 bg-line-faint"/>;
      // A table on paper: a header row and row rules, no container fill.
      case 'table': return <div key={i} data-slot="response-table" className="min-w-0 overflow-x-auto">
        <table className="w-full text-start type-body-sm">
          <thead><tr className="border-b border-line-faint">{block.head.map((h, j) => <th key={j} scope="col" className="h-(--menu-row) px-3 text-start type-label-sm text-text-2 first:ps-0">{text(h, false)}</th>)}</tr></thead>
          <tbody>{block.rows.map((row, r) => <tr key={r} className="rule-row">{row.map((c, j) => <td key={j} className="h-(--menu-row) px-3 py-1.5 align-top first:ps-0">{text(c, false)}</td>)}</tr>)}</tbody>
        </table>
      </div>;
    }
  });
}

/**
 * One markdown chunk. Memoised on its text and liveness, so a frozen chunk never re-renders while the
 * tail grows, and the tail keeps its identity when it freezes.
 */
const MarkdownChunk = memo(function MarkdownChunk({text, tags, live}: {text: string; tags: InlineTag[]; live: boolean}) {
  return <>{renderBlocks(parseMarkdown(text, live), {tail: live, tags, streaming: live})}</>;
});

const fenceLanguages: Record<string, Language> = {
  ts: 'ts', typescript: 'ts', tsx: 'tsx', js: 'js', javascript: 'js', jsx: 'js', json: 'json', jsonl: 'json',
  bash: 'bash', sh: 'bash', shell: 'bash', zsh: 'bash', console: 'bash', python: 'python', py: 'python', yaml: 'yaml', yml: 'yaml',
};

/** A fenced block as Glaze's CodeBlock: its language in the header, copy, and a body that scrolls past `maxLines`. */
function CodeChunk({text, open, maxLines}: {text: string; open: boolean; maxLines: number}) {
  const lines = text.split('\n');
  const lang = lines[0].replace(/^\s*(`{3,}|~{3,})\s*/, '').trim().toLowerCase();
  const body = lines.slice(1, open ? undefined : -1);
  return <CodeBlock data-slot="response-code" data-open={open || undefined} code={body.join('\n')} language={fenceLanguages[lang] ?? 'text'} maxLines={maxLines}/>;
}

function Pending({label}: {label: string}) {
  // A placeholder for a card, so it takes a card's footprint: a 36px row on paper with the faint edge.
  return <div data-slot="response-pending" className="flex h-(--row) items-center gap-2 rounded-overlay border border-line-faint bg-paper px-3">
    <Status status="running">{label}</Status>
  </div>;
}

type TagResult = {outcome: TagOutcome; node: React.ReactNode; rest?: string};

/** Resolves one tag chunk into one of the four outcomes. */
function resolveTag(chunk: string, tags: Record<string, TagRenderer>, open: boolean, expired: boolean): TagResult {
  const m = chunk.match(tagOpen)!;
  const [whole, name, rawAttrs] = m;
  const renderer = tags[name];
  if (!renderer) return {outcome: 'literal', node: <p className="whitespace-pre-wrap [overflow-wrap:anywhere]">{chunk}</p>};
  const attrs = parseAttrs(rawAttrs);
  const close = `</${name}>`;
  const after = chunk.slice(whole.length);
  const at = after.indexOf(close);
  const body = at === -1 ? after : after.slice(0, at);
  const trailing = at === -1 ? '' : after.slice(at + close.length);

  if (renderer.json === false) {
    if (at !== -1) return {outcome: 'segment', node: renderer.render(body.trim(), attrs), rest: trailing};
    if (open && !expired) return {outcome: 'pending', node: <Pending label={renderer.pending}/>};
    // Never closed: the opening line reads as text and everything after it parses as markdown again.
    const [first, ...more] = chunk.split('\n');
    return {outcome: 'literal', node: <p className="[overflow-wrap:anywhere]">{first}</p>, rest: more.join('\n')};
  }

  const end = completeJsonEnd(body);
  if (end !== -1) {
    try {
      const data = JSON.parse(body.slice(0, end));
      // A value that completed without its close tag still renders; what follows parses as markdown.
      return {outcome: 'segment', node: renderer.render(data, attrs), rest: (at === -1 ? body.slice(end) : body.slice(end) + trailing).replace(new RegExp(`^\\s*${close.replace('/', '\\/')}`), '')};
    } catch {
      return {outcome: 'discard', node: null, rest: at === -1 ? body.slice(end) : trailing};
    }
  }
  const v = viableLength(body);
  if (v === 0 && body.trim()) return {outcome: 'literal', node: <p className="whitespace-pre-wrap [overflow-wrap:anywhere]">{body.trim()}</p>, rest: trailing};
  // Still a viable prefix: the placeholder holds through a stall, so the box never flickers. Only the
  // end of the stream discards it.
  if (v >= body.length && at === -1) return open ? {outcome: 'pending', node: <Pending label={renderer.pending}/>} : {outcome: 'discard', node: null};
  // Broken JSON: drop the JSON-like part, keep any prose after it.
  return {outcome: 'discard', node: null, rest: (at === -1 ? body.slice(v) : trailing)};
}

const responseVariants = cva('flex min-w-0 flex-col text-text-1 break-words', {
  variants: {
    size: {
      default: 'gap-3 type-body',
      sm: 'gap-2 type-body-sm',
    },
  },
  defaultVariants: {size: 'default'},
});

type ResponseProps = Omit<React.ComponentProps<'div'>, 'children'> & VariantProps<typeof responseVariants> & {
  /** The markdown received so far. */
  children: string;
  /** More text is coming: paces bursts, closes dangling syntax, holds tags. */
  streaming?: boolean;
  /** Turn the paced reveal off and render every delta at once. */
  pace?: boolean;
  /** Structured tags the agent can emit, by name. */
  tags?: Record<string, TagRenderer>;
  /** Inline tokens such as [n] citations. Keep the array stable: its pattern is cached per array. */
  inlineTags?: InlineTag[];
  /** Ms an unclosed tag may go without growing before it stops holding the answer. */
  tagTimeout?: number;
  /** Lines of a code block before its body scrolls. 24 keeps a block inside one screen. */
  maxCodeLines?: number;
};

function Response({children, streaming = false, pace = true, tags, inlineTags = noTags, tagTimeout = 8000, maxCodeLines = 24, size = 'default', className, ...props}: ResponseProps) {
  const text = usePacedText(children, streaming, pace);
  const streamed = useRef(streaming);
  if (streaming) streamed.current = true;
  const tagMap = tags ?? noTagMap;
  const isTag = useMemo(() => (name: string) => Object.hasOwn(tagMap, name), [tagMap]);
  const [expiredAt, setExpiredAt] = useState<number | null>(null);

  // Renders `source` (which starts at offset `base` in the text) as chunks. Text left after a tag (its
  // value completed without a close tag, or a text tag released at the timeout) is chunked again, so a
  // fence or another tag after it still renders as one. Records the open tag at the live end, if any.
  let tailKey = '';
  const render = (source: string, base: number, depth: number): React.ReactNode[] => {
    const chunks = splitChunks(source, isTag);
    return chunks.map((chunk, i) => {
      const start = base + chunk.start;
      const live = i === chunks.length - 1 && streaming;
      if (chunk.kind === 'fence') {
        const open = !/^\s{0,3}(`{3,}|~{3,})\s*$/.test(chunk.text.split('\n').at(-1) ?? '') || chunk.text.split('\n').length === 1;
        return <CodeChunk key={start} text={chunk.text} open={open} maxLines={maxCodeLines}/>;
      }
      if (chunk.kind === 'tag') {
        const r = resolveTag(chunk.text, tagMap, live, expiredAt === start);
        if (live && (r.outcome === 'pending' || expiredAt === start)) tailKey = `${start}:${chunk.text.length}`;
        const rest = r.rest?.trim() && depth < 8 ? r.rest : '';
        return <Fragment key={start}>
          <div data-slot="response-tag" data-outcome={r.outcome} className="min-w-0">{r.node}</div>
          {rest && render(rest, start + chunk.text.length - rest.length, depth + 1)}
        </Fragment>;
      }
      return <MarkdownChunk key={start} text={chunk.text} tags={inlineTags} live={live}/>;
    });
  };
  const nodes = render(text, 0, 0);

  // Unclosed-tag timeout: when the open tag at the live end stops growing for tagTimeout ms, a text tag
  // stops holding. A JSON tag whose body is still viable keeps its placeholder until the stream ends.
  useEffect(() => {
    setExpiredAt(null);
    if (!tailKey || !streaming) return;
    const t = setTimeout(() => setExpiredAt(Number(tailKey.split(':')[0])), tagTimeout);
    return () => clearTimeout(t);
  }, [tailKey, streaming, tagTimeout]);

  return <div
    data-slot="response"
    data-streaming={streaming || undefined}
    data-streamed={streamed.current || undefined}
    aria-busy={streaming || undefined}
    className={cn(responseVariants({size}), className)}
    {...props}
  >{nodes}</div>;
}

const noTagMap: Record<string, TagRenderer> = {};

export {
  Response, usePacedText, splitChunks, parseMarkdown, resolveTag, viableLength, completeJsonEnd, closeJson, nextCut, paceStep, safeHref, responseVariants,
  type ResponseProps, type TagRenderer, type TagOutcome, type InlineTag,
};
